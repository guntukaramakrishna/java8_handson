package com.aexp.alerts.notifier;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.aexp.alerts.MailClient;
import com.aexp.alerts.model.EventLog;
import com.aexp.alerts.model.ServerDetails;
import com.aexp.alerts.util.DBUtil;

public class EmailNotifier {
	
	public void checkStatusAndSendEMail(){
		DBUtil util = new DBUtil();
		try {
			List<EventLog> events = util.getEvents();
			StringBuilder email = new StringBuilder();
			//get ServerDetails
			Map<Integer, Object> serverDetailsMap = DBUtil.getServerDetails();
			
			//get Error Details
			 Map<String,String> errorDetailsMap = DBUtil.getErrorDetails();
			
			email.append("<html><body>"
                    + "<table style='border:2px solid black'>");
			if(null != events && events.size() > 0){
				
				for(EventLog event: events){
					
					ServerDetails sd = (ServerDetails) serverDetailsMap.get(event.getServerId());
					String errorDesc = "";
					
					for (Entry<String, String> entry : errorDetailsMap.entrySet()) {
			            if (Integer.parseInt(entry.getValue())==event.getErrorId()) {
			                errorDesc = entry.getKey();
			            }
			        }
							
					 email.append("<tr bgcolor=\"#33CC99\">");
			            email.append("<td>");
			            email.append("Okta server: ")
						.append("Host: ").append(sd.getHostname());
			            email.append("</td>");

			            email.append("<td>");
			            email.append("IP: ").append(sd.getIpAddress());
			            email.append("</td>");

			            email.append("<td>");
			            email.append("Location: ").append(sd.getLocation());
			            email.append("</td>");
			            
			            email.append("<td>");
			            email.append("Timestamp (MST): ").append(event.getEventTimeStamp());
			            email.append("</td>");
			            
			            
			            email.append("<td>");
			            email.append("Error Message: ").append(errorDesc);
			            email.append("</td>");
			            
			            email.append("</tr>");
			            
					
				}
				 email.append("</table></body></html>");
				 
				 String subject = "Okta radius call failed on";
				 
				 MailClient mc = new MailClient();
				 mc.sendMail(email.toString(), subject) ;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void main(String[] args) {
		EmailNotifier en = new EmailNotifier();
		en.checkStatusAndSendEMail();
	}

}
