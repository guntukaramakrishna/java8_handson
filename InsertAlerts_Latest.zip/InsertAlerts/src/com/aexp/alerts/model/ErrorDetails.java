package com.aexp.alerts.model;

public class ErrorDetails {

	private String errorId;
}
