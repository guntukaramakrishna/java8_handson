package com.aexp.alerts.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class EventLog implements Serializable {
	
	
	private int eventId;
	private Timestamp eventTimeStamp; 
	private int serverId;
	private int errorId;
	private Timestamp createdTimeStamp; 
	public int getEventId() {
		return eventId;
	}
	public void setEventId(int eventId) {
		this.eventId = eventId;
	}
	public Timestamp getEventTimeStamp() {
		return eventTimeStamp;
	}
	public void setEventTimeStamp(Timestamp eventTimeStamp) {
		this.eventTimeStamp = eventTimeStamp;
	}
	public int getServerId() {
		return serverId;
	}
	public void setServerId(int serverId) {
		this.serverId = serverId;
	}
	public int getErrorId() {
		return errorId;
	}
	public void setErrorId(int errorId) {
		this.errorId = errorId;
	}
	public Timestamp getCreatedTimeStamp() {
		return createdTimeStamp;
	}
	public void setCreatedTimeStamp(Timestamp createdTimeStamp) {
		this.createdTimeStamp = createdTimeStamp;
	}
	

}
