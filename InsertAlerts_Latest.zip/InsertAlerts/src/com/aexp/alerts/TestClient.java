package com.aexp.alerts;


import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.logging.Logger;
import org.tinyradius.packet.AccessRequest;
import org.tinyradius.packet.RadiusPacket;
import org.tinyradius.util.RadiusClient;
import com.aexp.alerts.constants.Constants;
import com.aexp.alerts.model.ServerDetails;
import com.aexp.alerts.util.AppUtilities;
import com.aexp.alerts.util.DBUtil;

/**
 * Simple Radius command-line client.
 */
public class TestClient {

	private static final Logger LOG = Logger.getLogger("RadiusLog");
	public static Map<String, String> errDetailsMap = new HashMap<String, String>();

	public static void main(String[] args) throws Exception {

		org.apache.log4j.BasicConfigurator.configure();

		AppUtilities appUtilities = new AppUtilities();
		Properties props = appUtilities.loadProperties();
		RadiusClient rc = null;
		try {
			LOG.info("==========Start===========");
			String host = "";
			Timestamp timestamp = null;
			String ip = "";
			String errorMessage = "";

			errDetailsMap = DBUtil.getErrorDetails();
			Map<Integer, Object> serverDetailsMap = DBUtil.getServerDetails();

			// Retrieving serverDetails and iterating over it
			for (Integer serverId : serverDetailsMap.keySet()) {
				int errorId = 0;
				try {
					ServerDetails server = (ServerDetails) serverDetailsMap
							.get(serverId);
					host = server.getHostname();
					ip = server.getIpAddress();
					LOG.info("E3 Server : " + host + " (" + ip + ")");
					rc = new RadiusClient(ip,
							props.getProperty(Constants.SHARED));

					// 1. Send Access-Request
					AccessRequest ar = new AccessRequest(
							props.getProperty(Constants.USER_ID),
							props.getProperty(Constants.PASSWORD));
					ar.setAuthProtocol(AccessRequest.AUTH_PAP);
					timestamp = new java.sql.Timestamp(new Date().getTime());

					RadiusPacket response = rc.authenticate(ar);
					LOG.info("Response\n" + response + "\n");

					String mailTxt = response.toString();
				//	String resMsg = mailTxt.substring(mailTxt.toString().lastIndexOf("Reply-Message:") + 15);
					if (!mailTxt.toLowerCase().contains(
							"Access-Challenge".toLowerCase())) {
						errorMessage = mailTxt;
					}
				} catch (Exception e) {
					e.printStackTrace();
					errorMessage = e.getMessage();
				} finally {
					//Logic to get errtorID based on response text
					if(!"".equals(errorMessage)){
					for (String key : errDetailsMap.keySet()) {
						if (errorMessage.toLowerCase().contains(key))
							errorId = Integer.parseInt(errDetailsMap.get(key));
					}
					// add event log insert statement here
					DBUtil.addEventLog(timestamp, serverId, errorId);
				}
					LOG.info(errorMessage);
				}
			}
			LOG.info("==========End===========");
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			rc.close();
		}
	}

}