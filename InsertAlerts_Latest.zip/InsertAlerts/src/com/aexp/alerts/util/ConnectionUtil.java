package com.aexp.alerts.util;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.aexp.alerts.constants.Constants;

public class ConnectionUtil {

	public static Connection getDBConnection() throws IOException {
		//loading properties files
		
		AppUtilities appUtilities = new AppUtilities();
		Properties props = appUtilities.loadProperties();
		Connection dbConnection = null;
		try {
			Class.forName(props.getProperty(Constants.DB_DRIVER));
			
		} catch (ClassNotFoundException e) {	
				System.out.println(e.getMessage());	
		}
			try {
				dbConnection = DriverManager.getConnection(props.getProperty(Constants.DB_CONNECTION),
						props.getProperty(Constants.DB_USER), props.getProperty(Constants.DB_PASSWORD));
				return dbConnection;
			} catch (SQLException ex) {
				System.out.println(ex.getMessage());
			}
			
		return dbConnection;
	}

}
