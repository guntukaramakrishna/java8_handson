package com.aexp.alerts.constants;

public class Constants {

	
	public static final String DB_DRIVER = "DB_DRIVER";
	public static final String DB_CONNECTION = "DB_CONNECTION";
	public static final String DB_USER = "DB_USER";
	public static final String DB_PASSWORD = "DB_PASSWORD";
	public static final String SERVER_ID = "SERVER_ID";
	public static final String IP_ADDRESS = "IP_ADDRESS";
	public static final String HOSTNAME = "HOSTNAME";
	public static final String LOCATION = "LOCATION";
	public static final String DESCRIPTION = "DESCRIPTION";
	public static final String USER_ID = "USER_ID";
	public static final String PASSWORD = "PASSWORD";
	public static final String SHARED = "SHARED";
	public static final String ERROR_DESCRIPTION = "ERR_DESC";
	public static final String ERROR_ID = "ERR_ID";
	
	public static final String EVENT_ID = "EVENT_ID";
	public static final String EVENT_TS = "EVENT_TS";
	public static final String CREATED_TS = "CREATED_TS";
	public static final String EVENT_ERROR_ID = "ERROR_ID";
	
	public static final String DATETIME_PATTERN = "E MM/dd/yyyy HH:mm:ss.SSS";
	
	public static final String SQL_GET_SERVER_DETAILS = "SELECT * FROM dbo.server_details";
	public static final String SQL_GET_ERROR_DETAILS = "SELECT * FROM dbo.error_code";
	public static final String SQL_INSERT_EVENT_DETAILS = "INSERT INTO EVENT_LOG" + "(EVENT_TS, SERVER_ID, ERROR_ID, CREATED_TS) VALUES" + "(?,?,?,?)";
	public static final String SQL_GET_EVENT_DETAILS = "SELECT * FROM dbo.event_log order by event_id desc;";
	
	public static final String SMTP_HOST_PROPERTY = "SMTP_HOST_PROPERTY";
	public static final String SMTP_HOST = "mail.smtp.host";
	
	public static final String SMTP_PORT_PROPERTY = "SMTP_PORT_PROPERTY";
	public static final String SMTP_PORT = "mail.smtp.port";
}
