package com.avinash.java8;
import java.net.SocketTimeoutException;
import java.util.Properties;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.joda.time.DateTime;
import org.tinyradius.packet.AccessRequest;
import org.tinyradius.packet.RadiusPacket;
import org.tinyradius.util.RadiusClient;

import com.avinash.java8.model.ServerDetails;

/**
 * Simple Radius command-line client.
 */
public class TestClient {

	private static final Logger LOG = Logger.getLogger("RadiusLog");

	static Properties mailServerProp;
	static Session mailSession;
	static MimeMessage mailMessage;
	private static final String pattern = "E MM/dd/yyyy HH:mm:ss.SSS";
	static String passwordu = "Amex1234";

	public static void main(String[] args) 	throws Exception {

		RadiusClient rc = null;
		String logMessage = "";
		try {
			System.out.println("==========Start===========");
			
			String user = "oktauser1";
			String pass = "Test123$";
			String shared = "e3$okta$Rad$C0nn3ct";
			
//			String user = "vunni1";//e2
//			String pass = "Amex1234";//e2
//			String shared = "E2RadiusKey";//e2
			
			//String shared = "dummyshared";
			String host = "";
			String location = "";
			String timeStamp = DateTime.now().toString(pattern);
			String ip = "";
			//Retreiving serverDetails and iterating over it
			
			for (ServerDetails server: DBUtil.getServerDetails()){
				try {
					host = server.getHostname();
					location = server.getLocation();
					ip = server.getIpAddress();
					
					System.out.println("E3 Server : "+host+" ("+ip+")");
					rc = new RadiusClient(ip, shared);
					
					// 1. Send Access-Request
					AccessRequest ar = new AccessRequest(user, pass);
					ar.setAuthProtocol(AccessRequest.AUTH_PAP);

					timeStamp = DateTime.now().toString(pattern);
					RadiusPacket response = rc.authenticate(ar);
					System.out.println("Response\n" + response + "\n");

					String mailTxt = response.toString();
					String resMsg = mailTxt.substring(mailTxt.toString().lastIndexOf("Reply-Message:") + 15);
					if(!mailTxt.toLowerCase().contains("Access-Challenge".toLowerCase()) 
							&& !mailTxt.toLowerCase().contains("Proxy".toLowerCase())){
						logMessage = new StringBuilder()
									.append(" Okta Server: ").append(host).append(" (").append(ip).append(") ")
									.append("| Status: Failed")
									.append("| Type: "+response.getPacketTypeName())
									.append("| Message: "+resMsg).toString();
					
						
						//TODO: Code to get error codes based on response
					
						//inserting record in database
						int errorId = 0;
						DBUtil.addEventLog(server.getServerId(), errorId);
						
						sendMail(new StringBuilder()
								.append("Okta server: \n")
								.append("Host: ").append(host+"\n")
								.append("IP: ").append(ip+"\n")
								.append("Location: ").append(location+"\n").append("\n\n")
								.append("Timestamp (MST): ").append(timeStamp).append("\n\n")
								.append("Error Message: \n")
								.append(mailTxt).append("\n\n")
								.append("Please Action:\n")
								.append("Open a Sev 2 IMR and assign it to OKTAVFY_AXP_GL and call Anil Tottempudi")
								.toString(),
								new StringBuilder()
								.append("Okta radius call on ")
								.append(host).append(" (").append(ip).append(") ")
								.append("failed").toString()
								);
					}
				} catch(SocketTimeoutException e){
					logMessage = new StringBuilder() 
								.append(logMessage)
								.append(" Okta Server: ").append(host).append(" (").append(ip).append(") ")
								.append("| Status: Failed | SocketTimeoutException: ")
								.append(e.getMessage())
								.append(";").toString();
					String mailTxt1 = new StringBuilder()
									.append("Okta server: \n")
									.append("Host: ").append(host+"\n")
									.append("IP: ").append(ip+"\n")
									.append("Location: ").append(location+"\n").append("\n\n")
									.append("Timestamp (MST): ").append(timeStamp).append("\n\n")
									.append("Error Message: \n ")
									.append("SocketTimeoutException :")
									.append(e.getMessage()).append("\n\n")
									.append("Please Action:\n")
									.append("Open a Sev 2 IMR and assign it to OKTAVFY_AXP_GL and call Anil Tottempudi")
									.toString();
					String sub = new StringBuilder()
								.append("Okta radius call on ")
								.append(host).append(" (").append(ip).append(") ")
								.append("failed").toString();
					//e.printStackTrace();
					try {
						sendMail(mailTxt1,sub);
					} catch(MessagingException msgex){
							logMessage = logMessage + "| Email Sent: No;";
					}
				} catch(MessagingException e){
					logMessage = logMessage + "| Email Sent: No;";
				} catch(Exception e){
					logMessage = logMessage + "| Exception: "+e.getMessage()+";";
				}
			}
			if(!"".equals(logMessage)){
				LOG.info(logMessage);
			}
			System.out.println("==========End===========");
		} catch(Exception e){
			e.printStackTrace();
		} finally {
			rc.close();
		}
	}

	public static void sendMail(String mailTxt, String subject) throws Exception {
		try {

			mailServerProp = System.getProperties();
			mailServerProp.setProperty("mail.smtp.host", "E3-SMTP-GTM.aexp.com");
			//mailServerProp.setProperty("mail.smtp.host", "USAZPHX-MRLYe2-VIP.app.aexp.com");//e2
			//mailServerProp.setProperty("mail.smtp.host", "LPQIU523.TRCW.US.AEXP.COM");//e1
			mailServerProp.setProperty("mail.smtp.port", "25");

			mailSession = Session.getDefaultInstance(mailServerProp);

			mailMessage = new MimeMessage(mailSession);
			mailMessage.setFrom(new InternetAddress("OktaRadiusMonitoringAlert@aexp.com"));

			mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("OktaSupport@aexp.com"));
			mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("DirectoryServices-OperationalSupport@aexp.com"));
			mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("patrick.m.jenifer@aexp.com"));

			//mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("Anil.Tottempudi1@aexp.com"));
			//mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("vipin.v.unni@aexp.com"));

			mailMessage.setSubject(subject);
			mailMessage.setText(mailTxt);
	    	Transport.send(mailMessage);

		} catch(Exception exception) {
			throw exception;
		}
	}	
	
}
