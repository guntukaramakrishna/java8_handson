package com.avinash.java8;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.avinash.java8.model.ServerDetails;

public class DBUtil {

	/**
	 * Code to retrieve server details
	 * @return
	 * @throws SQLException
	 */
	public static List<ServerDetails> getServerDetails() throws SQLException {
		Connection dbConnection = null;
		Statement statement = null;
		String serverDetailsQry = "SELECT * FROM SERVER_DETAILS";
		List<ServerDetails> serverDetailsList = new ArrayList<ServerDetails>();
		try {
			dbConnection = ConnectionUtil.getDBConnection();
			statement = dbConnection.createStatement();
			ResultSet rs = statement.executeQuery(serverDetailsQry);
			while (rs.next()) {
				ServerDetails sd = new ServerDetails();
				sd.setServerId(rs.getInt("SERVER_ID"));
				sd.setIpAddress(rs.getString("IP_ADDRESS"));
				sd.setHostname(rs.getString("HOSTNAME"));
				sd.setLocation(rs.getString("LOCATION"));
				sd.setDescription(rs.getString("DESCRIPTION"));
				serverDetailsList.add(sd);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}

		}
		return serverDetailsList;
	}
	
	//TODO: Do same as serverdetails for ErrorCodes
	

	public static void addEventLog(int serverId, int errorId) throws SQLException {
		Connection dbConnection = null;
		PreparedStatement preparedStatement = null;
		String insertTableSQL = "INSERT INTO DBUSER" + "(USER_ID, USERNAME, CREATED_BY, CREATED_DATE) VALUES"
				+ "(?,?,?,?)";
		try {
			dbConnection = ConnectionUtil.getDBConnection();
			preparedStatement = dbConnection.prepareStatement(insertTableSQL);
			preparedStatement.setInt(1, 11);
			preparedStatement.setString(2, "mkyong");
			preparedStatement.setString(3, "system");

			// execute insert SQL stetement
			preparedStatement.executeUpdate();

			System.out.println("Record is inserted into DBUSER table!");

		} catch (SQLException e) {
			System.out.println(e.getMessage());

		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}

		}

	}

	private static java.sql.Timestamp getCurrentTimeStamp() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}
}
