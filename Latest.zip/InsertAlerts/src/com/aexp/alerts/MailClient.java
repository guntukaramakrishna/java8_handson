package com.aexp.alerts;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.aexp.alerts.constants.Constants;
import com.aexp.alerts.util.AppUtilities;

public class MailClient {
	static Properties mailServerProp;
	static Session mailSession;
	static MimeMessage mailMessage;

	public void sendMail(String mailTxt, String subject) throws Exception {
		try {

			AppUtilities appUtilities = new AppUtilities();
			Properties props = appUtilities.loadProperties();
			
			mailServerProp = System.getProperties();
			mailServerProp.setProperty(Constants.SMTP_HOST, props.getProperty(Constants.SMTP_HOST_PROPERTY));
			mailServerProp.setProperty(Constants.SMTP_PORT, props.getProperty(Constants.SMTP_PORT_PROPERTY));
			mailSession = Session.getDefaultInstance(mailServerProp);
			mailMessage = new MimeMessage(mailSession);
			mailMessage.setFrom(new InternetAddress(props.getProperty(Constants.MAIL_FROM)));
			mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(props.getProperty(Constants.MAIL_TO)));
			mailMessage.setSubject(subject);
			mailMessage.setContent(mailTxt, "text/html");
	    	Transport.send(mailMessage);

		} catch(Exception exception) {
			throw exception;
		}
	}

}
