package com.aexp.alerts.notifier;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;

import com.aexp.alerts.util.DBUtil;

public class ServerStatus {


	public void checkEventLogForError(){

		List<Integer> list = null;
		try {
			list = DBUtil.getAllServersDown();
			System.out.println("The servers are : " +list.size());
		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
		try {
			DBUtil.updateServerStatus(list);
		} catch (SQLException | IOException | ParseException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args){
		ServerStatus en = new ServerStatus();
		en.checkEventLogForError();
	}
}
