package com.aexp.alerts;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class AppUtilities {
	
	public Properties loadProperties() throws IOException{
		String env = System.getProperty("env");
		String config = "config-"+ env + ".properties";
		System.out.println(config);
		Properties configProps = new Properties();
		InputStream inStream = null;
		try {
		    inStream = getClass().getClassLoader().getResourceAsStream(config);
		    configProps.load(inStream);
		} finally {
		    if (inStream != null)
		        inStream.close();
		}
		return configProps;
	}

}
