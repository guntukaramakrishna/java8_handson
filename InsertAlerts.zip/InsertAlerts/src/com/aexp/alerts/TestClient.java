package com.aexp.alerts;
import java.net.SocketTimeoutException;
import java.util.Properties;
import java.util.logging.Logger;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.joda.time.DateTime;
import org.tinyradius.packet.AccessRequest;
import org.tinyradius.packet.RadiusPacket;
import org.tinyradius.util.RadiusClient;

import com.aexp.alerts.ServerDetails;

/**
 * Simple Radius command-line client.
 */
public class TestClient {

	private static final Logger LOG = Logger.getLogger("RadiusLog");

	private static final String pattern = "E MM/dd/yyyy HH:mm:ss.SSS";
	static String passwordu = "Amex1234";

	public static void main(String[] args) 	throws Exception {

		RadiusClient rc = null;
		String logMessage = "";
		try {
			System.out.println("==========Start===========");

			//			String user = "oktauser1";
			//			String pass = "Test123$";
			//			String shared = "e3$okta$Rad$C0nn3ct";

			String user = "vunni1";//e2
			String pass = "Amex1234";//e2
			String shared = "E2RadiusKey";//e2

			//String shared = "dummyshared";
			String host = "";
			String location = "";
			String timeStamp = DateTime.now().toString(pattern);
			String ip = "";
			//Retreiving serverDetails and iterating over it
			MailClient mailClient = new MailClient();

			for (ServerDetails server: DBUtil.getServerDetails()){
				int errorId = 0;
				try {
					host = server.getHostname();
					location = server.getLocation();
					ip = server.getIpAddress();

					System.out.println("E3 Server : "+host+" ("+ip+")");
					rc = new RadiusClient(ip, shared);

					// 1. Send Access-Request
					AccessRequest ar = new AccessRequest(user, pass);
					ar.setAuthProtocol(AccessRequest.AUTH_PAP);

					timeStamp = DateTime.now().toString(pattern);

					RadiusPacket response = rc.authenticate(ar);
					System.out.println("Response\n" + response + "\n");

					String mailTxt = response.toString();
					String resMsg = mailTxt.substring(mailTxt.toString().lastIndexOf("Reply-Message:") + 15);
					if(!mailTxt.toLowerCase().contains("Access-Challenge".toLowerCase()) 
							&& !mailTxt.toLowerCase().contains("Proxy".toLowerCase())){
						logMessage = new StringBuilder()
						.append(" Okta Server: ").append(host).append(" (").append(ip).append(") ")
						.append("| Status: Failed")
						.append("| Type: "+response.getPacketTypeName())
						.append("| Message: "+resMsg).toString();


						//TODO: Code to get error codes based on response

						//inserting record in database
						mailClient.sendMail(new StringBuilder()
						.append("Okta server: \n")
						.append("Host: ").append(host+"\n")
						.append("IP: ").append(ip+"\n")
						.append("Location: ").append(location+"\n").append("\n\n")
						.append("Timestamp (MST): ").append(timeStamp).append("\n\n")
						.append("Error Message: \n")
						.append(mailTxt).append("\n\n")
						.append("Please Action:\n")
						.append("Open a Sev 2 IMR and assign it to OKTAVFY_AXP_GL and call Anil Tottempudi")
						.toString(),
						new StringBuilder()
						.append("Okta radius call on ")
						.append(host).append(" (").append(ip).append(") ")
						.append("failed").toString()
								);
					}
				} catch(SocketTimeoutException e) {

					System.out.println("Came here...");
					logMessage = new StringBuilder() 
					.append(logMessage)
					.append(" Okta Server: ").append(host).append(" (").append(ip).append(") ")
					.append("| Status: Failed | SocketTimeoutException: ")
					.append(e.getMessage())
					.append(";").toString();
					String mailTxt1 = new StringBuilder()
					.append("Okta server: \n")
					.append("Host: ").append(host+"\n")
					.append("IP: ").append(ip+"\n")
					.append("Location: ").append(location+"\n").append("\n\n")
					.append("Timestamp (MST): ").append(timeStamp).append("\n\n")
					.append("Error Message: \n ")
					.append("SocketTimeoutException :")
					.append(e.getMessage()).append("\n\n")
					.append("Please Action:\n")
					.append("Open a Sev 2 IMR and assign it to OKTAVFY_AXP_GL and call Anil Tottempudi")
					.toString();
					String sub = new StringBuilder()
					.append("Okta radius call on ")
					.append(host).append(" (").append(ip).append(") ")
					.append("failed").toString();
					//e.printStackTrace();
					try {
						mailClient.sendMail(mailTxt1,sub);
					} catch(MessagingException msgex){
						logMessage = logMessage + "| Email Sent: No;";
					}
				} catch(MessagingException e){
					logMessage = logMessage + "| Email Sent: No;";
				} catch(Exception e){
					logMessage = logMessage + "| Exception: "+e.getMessage()+";";
				}finally{
					//add event log inert statemnt here
					DBUtil.addEventLog(timeStamp, server.getServerId(), errorId);
				}
			}
			if(!"".equals(logMessage)){
				LOG.info(logMessage);
			}
			System.out.println("==========End===========");
		} catch(Exception e){
			e.printStackTrace();
		} finally {
			rc.close();
		}
	}


}