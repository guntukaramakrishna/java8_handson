package com.aexp.alerts;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

import com.aexp.alerts.ServerDetails;

public class DBUtil {

	private static final Logger LOG = Logger.getLogger("DBUtil");
	
	/**
	 * Code to retrieve server details
	 * @return
	 * @throws SQLException
	 * @throws IOException 
	 */
	public static List<ServerDetails> getServerDetails() throws SQLException, IOException {
		LOG.info("Begin fetching server Details");
		
		Connection dbConnection = null;
		Statement statement = null;
		String serverDetailsQry = "SELECT * FROM dbo.server_details";
		List<ServerDetails> serverDetailsList = new ArrayList<ServerDetails>();
		try {
			dbConnection = ConnectionUtil.getDBConnection();
			statement = dbConnection.createStatement();
			ResultSet rs = statement.executeQuery(serverDetailsQry);
			while (rs.next()) {
				ServerDetails sd = new ServerDetails();
				sd.setServerId(rs.getInt("SERVER_ID"));
				sd.setIpAddress(rs.getString("IP_ADDRESS"));
				sd.setHostname(rs.getString("HOSTNAME"));
				sd.setLocation(rs.getString("LOCATION"));
				sd.setDescription(rs.getString("DESCRIPTION"));
				serverDetailsList.add(sd);
			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} finally {
			if (statement != null) {
				statement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}

		}
		LOG.info("End fetching server Details");
		return serverDetailsList;
	}
	
	//TODO:  for ErrorCodes
	

	public static void addEventLog(String eventTimeStamp, int serverId, int errorId) throws SQLException, IOException {
		
		LOG.info("Started adding records into EVENT_LOG table for serverId: "+serverId);
		
		Connection dbConnection = null;
		PreparedStatement preparedStatement = null;
		
		String insertTableSQL = "INSERT INTO EVENT_LOG" + "(EVENT_TS, SERVER_ID, ERROR_ID, CREATED_TS) VALUES"
				+ "(?,?,?,?)";
		try {
			dbConnection = ConnectionUtil.getDBConnection();
			preparedStatement = dbConnection.prepareStatement(insertTableSQL);
			DateTimeFormatter formatter = DateTimeFormat.forPattern("E MM/dd/yyyy HH:mm:ss.SSS");
			DateTime dt = formatter.parseDateTime(eventTimeStamp);
			preparedStatement.setDate(1, new java.sql.Date(dt.toDate().getTime()));
			preparedStatement.setInt(2, serverId);
			preparedStatement.setInt(3, errorId);
			preparedStatement.setTimestamp(4, getCurrentTimeStamp());

			// execute insert SQL statement
			preparedStatement.executeUpdate();

			LOG.info("Record is inserted into EVENT_LOG table for serverId: "+serverId);

		} catch (SQLException e) {
			LOG.info(e.getMessage());

		} finally {
			if (preparedStatement != null) {
				preparedStatement.close();
			}
			if (dbConnection != null) {
				dbConnection.close();
			}

		}

	}

	private static java.sql.Timestamp getCurrentTimeStamp() {
		java.util.Date today = new java.util.Date();
		return new java.sql.Timestamp(today.getTime());

	}
}
