package com.aexp.alerts;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class ConnectionUtil {

	private static final String DB_DRIVER = "DB_DRIVER";
	private static final String DB_CONNECTION = "jdbc:sqlserver://hqidwoktdb01;databaseName=non_ads_portal;";
	private static final String DB_USER = "nonadsportaluser";
	private static final String DB_PASSWORD = "nonadsportal123$";

	public static Connection getDBConnection() throws IOException {
		//loading properties files
		
		AppUtilities appUtilities = new AppUtilities();
		Properties props = appUtilities.loadProperties();
		Connection dbConnection = null;
		try {
			Class.forName(props.getProperty(DB_DRIVER));
		} catch (ClassNotFoundException e) {
			{
				System.out.println(e.getMessage());
			}
			try {
				dbConnection = DriverManager.getConnection(props.getProperty(DB_CONNECTION),
						props.getProperty(DB_USER), props.getProperty(DB_PASSWORD));
				return dbConnection;
			} catch (SQLException ex) {
				System.out.println(ex.getMessage());
			}
			

		}
		return dbConnection;
	}

}
