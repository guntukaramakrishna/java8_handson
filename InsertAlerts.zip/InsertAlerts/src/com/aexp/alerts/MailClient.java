package com.aexp.alerts;

import java.util.Properties;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class MailClient {
	static Properties mailServerProp;
	static Session mailSession;
	static MimeMessage mailMessage;

	public void sendMail(String mailTxt, String subject) throws Exception {
		try {

			mailServerProp = System.getProperties();
			mailServerProp.setProperty("mail.smtp.host", "E3-SMTP-GTM.aexp.com");
			//mailServerProp.setProperty("mail.smtp.host", "USAZPHX-MRLYe2-VIP.app.aexp.com");//e2
			//mailServerProp.setProperty("mail.smtp.host", "LPQIU523.TRCW.US.AEXP.COM");//e1
			mailServerProp.setProperty("mail.smtp.port", "25");

			mailSession = Session.getDefaultInstance(mailServerProp);

			mailMessage = new MimeMessage(mailSession);
			mailMessage.setFrom(new InternetAddress("OktaRadiusMonitoringAlert@aexp.com"));

//			mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("OktaSupport@aexp.com"));
//			mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("DirectoryServices-OperationalSupport@aexp.com"));
//			mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("patrick.m.jenifer@aexp.com"));

			//mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("Anil.Tottempudi1@aexp.com"));
			//mailMessage.addRecipient(Message.RecipientType.TO, new InternetAddress("vipin.v.unni@aexp.com"));

			mailMessage.setSubject(subject);
			mailMessage.setText(mailTxt);
	    	Transport.send(mailMessage);

		} catch(Exception exception) {
			throw exception;
		}
	}

}
